Mole Mania - Protech Bug Eraser 0.1  [Radiant Nighte]



Fixes:  [Japan, USA, Europe]
- Detect SGB2 and play correct music tempo




Source: MIT License
https://github.com/radimerry/mole-mania/tree/game-fixes




Notes:
- Sprite overlap glitches are due to buggy priority problems with DMG hardware
  (some emulators or handhelds may have option to fix oam sorting)
